/**
 * Memory.h - Memory library
 */

#ifndef Memory_h
#define Memory_h

#ifdef __cplusplus
extern "C" {
#endif

int freeMemory();

#ifdef  __cplusplus
}
#endif


#endif
